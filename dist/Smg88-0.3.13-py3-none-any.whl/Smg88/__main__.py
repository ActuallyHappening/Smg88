import testing.testmanager as testmanager
print("__main__ run :)")

testmanager.importTests()
testmanager.runtests()
