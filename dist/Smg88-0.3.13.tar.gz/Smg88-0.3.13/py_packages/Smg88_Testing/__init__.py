print("__init__ called for testing package :)")
