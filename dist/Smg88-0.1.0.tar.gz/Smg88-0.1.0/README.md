# Smg88
 Provides an array of commonly used functions and features
